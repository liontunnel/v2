from kyt import *
from datetime import datetime
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("𝗦𝗦𝗛 𝗪𝗦", "ssh"), Button.inline("𝗩𝗠𝗘𝗦𝗦", "vmess")],
        [Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡", "trojan"), Button.inline("𝗩𝗣𝗦 𝗜𝗡𝗙𝗢", "info")],
        [Button.inline("𝗦𝗘𝗧𝗜𝗡𝗚", "setting"), Button.inline("𝗟𝗜𝗦𝗧 𝗦𝗘𝗪𝗔", "ls-ip")],
        [Button.url("𝗚𝗥𝗨𝗣 𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠", "https://t.me/PIHAKSMART")]  # Add URL button here
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await (f"**Akses Ditolak: Anda tidak terdaftar  Untuk daftar beli VPS dan auto script owner** @XLSMARTLC")
    elif val == "true":
        # Mengambil jumlah akun dari database
        ssh = subprocess.check_output("cat /etc/ssh/.ssh.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        vms = subprocess.check_output("cat /etc/xray/config.json | grep '###' | wc -l", shell=True).decode("ascii").strip()
        vls = subprocess.check_output("cat /etc/vless/.vless.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        trj = subprocess.check_output("cat /etc/trojan/.trojan.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        ssk = subprocess.check_output("cat /etc/shadowsocks/.shadowsocks.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        
        # Mengambil informasi sistem
        namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode("ascii").strip().replace('"','')
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
        city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()
        
        # Mengambil status running VPS
        uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()  # Get the uptime of the VPS
        
        # Mengambil RAM Usage
        ram_usage = subprocess.check_output("free -h | grep Mem", shell=True).decode("ascii").strip()
        total_ram = ram_usage.split()[1]  # Total RAM
        used_ram = ram_usage.split()[2]   # Used RAM
        free_ram = ram_usage.split()[3]   # Free RAM
        
        # Mengambil ping VPS (ping 1 time)
        try:
            ping = subprocess.check_output(f"ping -c 1 {ipsaya}", shell=True).decode("ascii")
            ping_time = ping.split('time=')[1].split(' ms')[0]  # Extract the ping time
        except subprocess.CalledProcessError:
            ping_time = "N/A"  # If the ping fails, return N/A
        
        # Mengambil tanggal dan waktu saat ini
        current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Current date and time
        current_time = datetime.now().strftime("%H:%M:%S")  # Current time (jam)

        # Mengambil informasi pengguna
        user_id = sender.id
        username = sender.username

        # Pesan menu dengan semua informasi
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**≡  DP75X TUNNEL  MENU BOT  ≡**
**━━━━━━━━━━━━━━━━━━━━━━━**
**🖥️ • VPS DETAILS**
**🌍 • OS :** `{namaos}`
**📅 • Date :** `{current_datetime}`
**🌆 • City :** `{city}`
**🏠 • Host :** `{DOMAIN}`
**⚡ •** `{uptime}`
**🌐 • IP VPS :** `{ipsaya}`
**⏱️ • Ping :** `{ping_time} Ms`
**💻 • RAM :** `{total_ram}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔒 • ACCOUNT STATUS**
**🔑 • SSH :** `{ssh} Account`
**💻 • VMESS :** `{vms} Account`
**🔒 • TROJAN :** `{trj} Account`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🧑‍💻 • USER PROFILE**
**👤 • User ID :** `{user_id}`
**📝 • Username :** @{username}
**━━━━━━━━━━━━━━━━━━━━━**
"""
        # Kirim gambar dan pesan sekaligus
        await event.respond(
            message=msg, 
            buttons=inline
        )